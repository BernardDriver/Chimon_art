# Chimon 花纹生成器

基于 Next.js + Tailwind + Replicate 的现代非遗花纹图案生成工具。

## 开发启动
```bash
npm install
npm run dev
```

## Vercel 部署建议
- 设置环境变量 `REPLICATE_API_TOKEN`
- 自动连接 GitHub 仓库部署
